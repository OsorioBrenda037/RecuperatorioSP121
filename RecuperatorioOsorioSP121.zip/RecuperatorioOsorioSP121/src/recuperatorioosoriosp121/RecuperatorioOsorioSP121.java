
package recuperatorioosoriosp121;

import java.time.LocalDate;
import java.util.List;
import java.util.function.Predicate;
import model.EventoMusical;
import model.GeneroMusical;
import service.Inventario;

public class RecuperatorioOsorioSP121 {

    public static void main(String[] args) {
        try {
            Inventario<EventoMusical> gestor = new Inventario<>();
            // Crear algunos eventos musicales
            gestor.agregarEvento(new EventoMusical(1, "Rock Fest", LocalDate.of(2024, 3, 15), "Queen Revival", GeneroMusical.ROCK));
           
            gestor.agregarEvento(new EventoMusical(2, "Jazz Night", LocalDate.of(2024, 6, 20), "John Doe Quintet", GeneroMusical.JAZZ));
           
            gestor.agregarEvento(new EventoMusical(3, "Pop Party", LocalDate.of(2024, 8, 5), "Taylor Tribute", GeneroMusical.POP));
           
            gestor.agregarEvento(new EventoMusical(4, "Electronic Vibes", LocalDate.of(2024, 10, 12), "DJ Nova", GeneroMusical.ELECTRONICA));
            
            //funciona
            // Mostrar todos los eventos
            System.out.println("Lista inicial de eventos:");
            gestor.paraCadaElemento(e -> System.out.println(e));
            
            //funciona
            // Ordenar por fecha (orden natural)
            System.out.println("\nEventos ordenados por fecha:");
            gestor.ordenar();
            gestor.paraCadaElemento(e -> System.out.println(e));
            
            //funciona
            // Ordenar por nombre de evento
            System.out.println("\nEventos ordenados por nombre:");
            gestor.ordenar((a,b) -> a.getNombre().compareTo(b.getNombre()));
            gestor.paraCadaElemento(e -> System.out.println(e));
            
            //funciona
            // Filtrar por género
            System.out.println("\nEventos de género ROCK:");
            List<EventoMusical> rockEvents = gestor.filtrar(a -> a.getGeneroMusical().equals(GeneroMusical.ROCK));
           
            rockEvents.forEach(System.out::println);
            
            //funciona
            // Filtrar por palabra clave en el nombre
            System.out.println("\nEventos que contienen 'Night' en el nombre:");
            List<EventoMusical> nightEvents = gestor.filtrar(a -> a.getNombre().contains("Night"));

            nightEvents.forEach(System.out::println);
            
            //funciona
            // Buscar por rango de fechas
            System.out.println("\nEventos entre el 01/01/2024 y el 31/07/2024:");
            List<EventoMusical> dateRangeEvents = gestor.buscarPorFecha(
            LocalDate.of(2024, 1, 1),
            LocalDate.of(2024, 7, 31)
            );
            dateRangeEvents.forEach(System.out::println);
            
            //funciona
            // Guardar y cargar en formato binario
            System.out.println("\nGuardando y cargando eventos en binario...");
            gestor.serializar("src/data/eventos.bin");
            
            //gestor.limpiar(); // Vaciar el gestor
            
            //funciona
            gestor.deserializar("src/data/eventos.bin");
            gestor.paraCadaElemento(e -> System.out.println(e));
            
            //funciona
            // Guardar y cargar en formato CSV
            System.out.println("\nGuardando y cargando eventos en CSV...");
            gestor.guardarCSV("src/data/eventos.csv");
            
            //gestor.limpiar(); // Vaciar el gestor
            
            //funciona
            gestor.cargarCSV("src/data/eventos.csv", linea -> EventoMusical.fromCSV(linea));
            gestor.paraCadaElemento(e -> System.out.println(e));
            
            //funciona
            // Filtro dinámico usando Predicate
            System.out.println("\nFiltrar eventos dinámicamente (artista contiene 'DJ')");
            Predicate<EventoMusical> filtroArtista = evento -> evento.getArtista().contains("DJ");
            List<EventoMusical> filtroDinamico = gestor.filtrar(filtroArtista);
            filtroDinamico.forEach(System.out::println);

        } catch (RuntimeException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    
}
