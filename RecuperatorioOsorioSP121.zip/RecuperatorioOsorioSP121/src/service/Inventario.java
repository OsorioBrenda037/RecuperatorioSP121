
package service;

import EventoYaExisteException.EventoYaExisteException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import model.Evento;
import model.EventoMusical;

public class Inventario<T extends Evento> implements Almacenable<T>, Serializable{
    List<T> items = new ArrayList<>();
    @Override
    public void agregarEvento(T item) {
        if (item == null) {
            throw new IllegalArgumentException("No se puede agregar un objeto nulo.");
        }
        
        if (items.contains(item)) {
            throw new EventoYaExisteException();
        } 
        items.add(item);  
    }

    @Override
    public T obtenerEvento(int indice) {
        validarIndice(indice);
        return items.get(indice);
    }

    @Override
    public void eliminarEvento(int indice) {
        validarIndice(indice);
        items.remove(indice);
    }

    private void validarIndice(int indice) {
        if (indice < 0 || indice >= items.size()) {
            throw new IllegalArgumentException("El indice debe ser un entero positivo.");
        }
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();
        
        for (T item: items) {
            if (criterio.test(item)) {
                listaFiltrada.add(item);
            }
        }
        
        return listaFiltrada;
    }

    @Override
    public List<T> buscarPorFecha(LocalDate fechaInicio, LocalDate fehcaFin) {
        List<T> porRango = new ArrayList<>();
        for (T item: items) {
            if (!item.getFecha().isBefore(fechaInicio) && !item.getFecha().isAfter(fehcaFin)) {
                porRango.add(item);
            }
        }
        return porRango;
    }

    @Override
    public void ordenar() {
        ordenar((Comparator <T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparator) {
        items.sort(comparator);
    }

    @Override
    public void serializar(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            
            salida.writeObject(items);
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void deserializar(String path) {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            
            items = (List<T>) input.readObject();
            
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarCSV(String path) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id, nombre, fecha, artista, generoMusical\n");
            for (T item: items) {
                bw.write(item.toCSV() + "\n");
            }
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en archivo.");
        }
    }

    @Override
    public void cargarCSV(String path, Function<String, T> funcion) {
        items.clear();
        
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine();
            while ((linea = bf.readLine()) != null) {
                items.add(funcion.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en archivo.");
        }
    }

    @Override
    public void paraCadaElemento(Consumer<T> consumidor) {
        for (T item: items) {
            consumidor.accept(item);
        }
    }
}
