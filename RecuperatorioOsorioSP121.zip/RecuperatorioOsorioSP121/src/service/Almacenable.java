
package service;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Almacenable <T>{
    void agregarEvento(T item);
    T obtenerEvento(int indice);
    void eliminarEvento(int indice);
    List<T> filtrar(Predicate<T> criterio);
    List<T> buscarPorFecha(LocalDate fechaIncio, LocalDate fehcaFin);
    void ordenar();
    void ordenar(Comparator<T> comparator);
    void serializar(String path);
    void deserializar(String path);
    void guardarCSV(String path);
    void cargarCSV(String path, Function<String, T> funcion);
    void paraCadaElemento(Consumer<T> consumidor);
}
