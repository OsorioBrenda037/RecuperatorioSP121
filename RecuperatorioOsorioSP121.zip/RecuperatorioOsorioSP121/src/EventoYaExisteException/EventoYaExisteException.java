
package EventoYaExisteException;

public class EventoYaExisteException extends RuntimeException{
    private static final String MENSAJE = "El evento ya esta en la lista.";

    public EventoYaExisteException() {
        super(MENSAJE);
    }
    
    
}
